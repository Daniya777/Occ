# Snap → Parse → Table (GitHub Pages)
One-file web app that does on-device OCR (Tesseract.js) of a receipt/menu photo and turns it into an editable table with totals and CSV/JSON export.

## How to publish on GitHub Pages
1. Create a new repo (public).
2. Upload **index.html** to the repo root.
3. Go to **Settings → Pages**:
   - Source: **Deploy from a branch**
   - Branch: **main / (root)** → Save
4. Wait ~1 minute. Site URL will appear under **Pages**.

Open the URL in Safari on iPhone. Everything runs in-browser; no server required.
